require("dotenv").config();

const express = require("express");
const path = require("path");
const { createClient } = require("@supabase/supabase-js");

const app = express();
const PORT = process.env.PORT || 3000;
const supabaseUrl = process.env.SUPABASE_URL;
const supabaseKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

app.use(express.json({ limit: "20kb" }));
app.use(express.static(path.join(__dirname, "public")));

let supabase = null;
if (supabaseUrl && supabaseKey) {
  supabase = createClient(supabaseUrl, supabaseKey, {
    auth: { persistSession: false, autoRefreshToken: false }
  });
}

function requireDatabase(req, res, next) {
  if (!supabase) {
    return res.status(503).json({
      error: "Database not configured. Add SUPABASE_URL and SUPABASE_SERVICE_ROLE_KEY."
    });
  }
  next();
}

function cleanText(value, max = 120) {
  if (typeof value !== "string") return "";
  return value.trim().replace(/\s+/g, " ").slice(0, max);
}

app.get("/api/health", (req, res) => {
  res.json({ ok: true, databaseConfigured: Boolean(supabase) });
});

app.get("/api/relationships", requireDatabase, async (req, res) => {
  const { data, error } = await supabase
    .from("relationships")
    .select("id, subject, relation, object, created_at")
    .order("created_at", { ascending: false })
    .limit(500);

  if (error) return res.status(500).json({ error: error.message });
  res.json({ relationships: data || [] });
});

app.post("/api/relationships", requireDatabase, async (req, res) => {
  const subject = cleanText(req.body.subject);
  const relation = cleanText(req.body.relation);
  const object = cleanText(req.body.object);

  if (!subject || !relation || !object) {
    return res.status(400).json({ error: "Subject, relationship, and object are required." });
  }

  const { data: existing, error: lookupError } = await supabase
    .from("relationships")
    .select("id")
    .ilike("subject", subject)
    .ilike("relation", relation)
    .ilike("object", object)
    .limit(1);

  if (lookupError) return res.status(500).json({ error: lookupError.message });
  if (existing && existing.length) {
    return res.status(409).json({ error: "That relationship is already stored." });
  }

  const { data, error } = await supabase
    .from("relationships")
    .insert({ subject, relation, object })
    .select("id, subject, relation, object, created_at")
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json({ relationship: data });
});

app.delete("/api/relationships/:id", requireDatabase, async (req, res) => {
  const id = Number(req.params.id);
  if (!Number.isInteger(id) || id <= 0) {
    return res.status(400).json({ error: "Invalid relationship ID." });
  }

  const { error } = await supabase.from("relationships").delete().eq("id", id);
  if (error) return res.status(500).json({ error: error.message });
  res.json({ ok: true });
});

app.get("/api/knowledge", requireDatabase, async (req, res) => {
  const { data, error } = await supabase
    .from("knowledge")
    .select("id, question, answer, created_at")
    .order("created_at", { ascending: false })
    .limit(500);

  if (error) return res.status(500).json({ error: error.message });
  res.json({ knowledge: data || [] });
});

app.post("/api/knowledge", requireDatabase, async (req, res) => {
  const question = cleanText(req.body.question, 300);
  const answer = cleanText(req.body.answer, 1000);

  if (!question || !answer) {
    return res.status(400).json({ error: "Question and answer are required." });
  }

  const { data, error } = await supabase
    .from("knowledge")
    .upsert({ question, answer }, { onConflict: "question" })
    .select("id, question, answer, created_at")
    .single();

  if (error) return res.status(500).json({ error: error.message });
  res.status(201).json({ knowledge: data });
});

app.get("*", (req, res) => {
  res.sendFile(path.join(__dirname, "public", "index.html"));
});

app.listen(PORT, "0.0.0.0", () => {
  console.log(`Kakashi AI is running on http://localhost:${PORT}`);
  if (!supabase) {
    console.warn("Database not configured yet. Add values to .env to enable shared learning.");
  }
});
