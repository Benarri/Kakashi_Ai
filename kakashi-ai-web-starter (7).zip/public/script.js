const $ = (selector) => document.querySelector(selector);
const statusEl = $("#status");
const chat = $("#chat");
const factsEl = $("#facts");
const learnedEl = $("#learned");
const countEl = $("#count");
const toastEl = $("#toast");

let relationships = [];
let learned = [];

function showToast(message) {
  toastEl.textContent = message;
  toastEl.classList.add("show");
  clearTimeout(showToast.timer);
  showToast.timer = setTimeout(() => toastEl.classList.remove("show"), 2800);
}

async function api(url, options = {}) {
  const response = await fetch(url, {
    ...options,
    headers: { "Content-Type": "application/json", ...(options.headers || {}) }
  });
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body.error || `Request failed (${response.status})`);
  return body;
}

function addBubble(who, message, type) {
  const bubble = document.createElement("div");
  bubble.className = `bubble ${type}`;
  const strong = document.createElement("strong");
  strong.textContent = who;
  const p = document.createElement("p");
  p.textContent = message;
  bubble.append(strong, p);
  chat.appendChild(bubble);
  chat.scrollTop = chat.scrollHeight;
}

function normalize(s) {
  return String(s || "").toLowerCase().replace(/[’']/g, "").replace(/[^a-z0-9\s-]/g, " ").replace(/\s+/g, " ").trim();
}

function answerQuestion(question) {
  const q = normalize(question);
  if (!q) return "Ask me something about what the community has taught me.";

  const greetings = ["hello", "hi", "hey", "good morning", "good afternoon"];
  if (greetings.some(g => q === g || q.startsWith(g + " "))) {
    return "Hey! I'm Kakashi AI. Ask me a question or teach me a new fact.";
  }
  if (q.includes("your name") || q === "who are you") {
    return "I'm Kakashi AI, a community chatbot still learning one fact at a time.";
  }
  if (q.includes("joke")) {
    return ["Why do programmers prefer dark mode? Because light attracts bugs!",
      "Why was the computer cold? It left its Windows open!",
      "There are 10 kinds of people: those who understand binary and those who don't."][Math.floor(Math.random() * 3)];
  }

  const tokens = q.split(" ").filter(w => !["who","what","where","when","is","are","the","a","an","of","to","my","your","please","tell","me","about","does","do","whos","whats"].includes(w));
  let best = null;
  let bestScore = 0;
  for (const r of relationships) {
    const subject = normalize(r.subject);
    const relation = normalize(r.relation);
    const object = normalize(r.object);
    const subjectHit = q.includes(subject);
    const objectHit = q.includes(object);
    const relationWords = relation.split(" ");
    const relationHit = relationWords.some(word => tokens.includes(word)) || q.includes(relation);
    if (subjectHit && relationHit) {
      const score = 3 + (objectHit ? 1 : 0);
      if (score > bestScore) { best = `${r.subject}'s ${r.relation} is ${r.object}.`; bestScore = score; }
    } else if (objectHit && relationHit) {
      const score = 2;
      if (score > bestScore) { best = `${r.subject} is the ${r.relation} of ${r.object}.`; bestScore = score; }
    }
  }
  if (best) return best;

  const exact = learned.find(item => normalize(item.question) === q);
  if (exact) return exact.answer;

  let candidate = null, candidateScore = 0;
  for (const item of learned) {
    const words = normalize(item.question).split(" ").filter(Boolean);
    const overlap = words.filter(word => tokens.includes(word)).length;
    const score = overlap / Math.max(words.length, tokens.length, 1);
    if (score > candidateScore) { candidate = item; candidateScore = score; }
  }
  if (candidate && candidateScore >= 0.45) return candidate.answer;
  return "I don't know that yet. You can teach me using the forms below!";
}

function renderFacts() {
  factsEl.replaceChildren();
  if (!relationships.length) {
    factsEl.innerHTML = '<p class="hint">No relationships yet. Add the first one above.</p>';
  }
  for (const r of relationships) {
    const row = document.createElement("div");
    row.className = "fact";
    const main = document.createElement("div");
    main.className = "fact-main";
    const s = document.createElement("strong"); s.textContent = r.subject;
    const rel = document.createElement("span"); rel.className = "arrow"; rel.textContent = ` —${r.relation}→ `;
    const o = document.createElement("strong"); o.textContent = r.object;
    main.append(s, rel, o);
    const del = document.createElement("button");
    del.className = "delete"; del.type = "button"; del.textContent = "Remove";
    del.addEventListener("click", async () => {
      if (!confirm("Remove this shared relationship for everyone?")) return;
      try {
        await api(`/api/relationships/${r.id}`, { method: "DELETE" });
        showToast("Relationship removed.");
        await refreshAll();
      } catch (e) { showToast(e.message); }
    });
    row.append(main, del);
    factsEl.append(row);
  }
  countEl.textContent = `${relationships.length} relationships · ${learned.length} answers`;
}

function renderLearned() {
  learnedEl.replaceChildren();
  if (!learned.length) {
    learnedEl.innerHTML = '<p class="hint">No answers have been taught yet.</p>';
    return;
  }
  for (const item of learned) {
    const card = document.createElement("div");
    card.className = "qa";
    const q = document.createElement("strong"); q.textContent = `Q: ${item.question}`;
    const a = document.createElement("p"); a.textContent = `A: ${item.answer}`;
    card.append(q, a);
    learnedEl.append(card);
  }
}

async function refreshAll() {
  try {
    const [r, k] = await Promise.all([
      api("/api/relationships"),
      api("/api/knowledge")
    ]);
    relationships = r.relationships || [];
    learned = k.knowledge || [];
    statusEl.textContent = "Database connected";
    statusEl.className = "status online";
    renderFacts();
    renderLearned();
  } catch (e) {
    statusEl.textContent = "Database not ready";
    statusEl.className = "status offline";
    factsEl.innerHTML = `<p class="hint">${escapeHtml(e.message)}. Configure Supabase and run sql/schema.sql.</p>`;
    learnedEl.innerHTML = '<p class="hint">Shared answers will appear after the database is connected.</p>';
    countEl.textContent = "Not connected";
  }
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));
}

$("#ask-form").addEventListener("submit", (event) => {
  event.preventDefault();
  const input = $("#question");
  const question = input.value.trim();
  if (!question) return;
  addBubble("You", question, "user");
  addBubble("Kakashi", answerQuestion(question), "kakashi");
  input.value = "";
});

$("#relationship-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());
  const button = form.querySelector("button");
  button.disabled = true;
  try {
    await api("/api/relationships", { method: "POST", body: JSON.stringify(data) });
    form.reset();
    showToast("Relationship shared with the community!");
    await refreshAll();
  } catch (e) { showToast(e.message); }
  finally { button.disabled = false; }
});

$("#knowledge-form").addEventListener("submit", async (event) => {
  event.preventDefault();
  const form = event.currentTarget;
  const data = Object.fromEntries(new FormData(form).entries());
  const button = form.querySelector("button");
  button.disabled = true;
  try {
    await api("/api/knowledge", { method: "POST", body: JSON.stringify(data) });
    form.reset();
    showToast("Kakashi learned an answer!");
    await refreshAll();
  } catch (e) { showToast(e.message); }
  finally { button.disabled = false; }
});

$("#refresh").addEventListener("click", refreshAll);
refreshAll();
