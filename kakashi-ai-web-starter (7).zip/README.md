# Kakashi AI — Shared Web Starter

A small browser-based Kakashi AI learning experiment. It stores community relationships and question/answer pairs in Supabase so all visitors share the same knowledge.

## Requirements

- Node.js 18 or newer
- A Supabase project
- A hosting provider for the Node server (for example, Render)

## Run locally

1. Install dependencies:

   ```bash
   npm install
   ```

2. Copy `.env.example` to `.env`.
3. Set `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` in `.env`.
4. In the Supabase SQL Editor, run the contents of `sql/schema.sql`.
5. Start the server:

   ```bash
   npm start
   ```

6. Open <http://localhost:3000>.

If you haven't configured Supabase yet, the page will load but shared learning won't work.

## Deploy

1. Push these project files to a GitHub repository.
2. Create a Render Web Service connected to that repository.
3. Build command: `npm install`
4. Start command: `npm start`
5. Add `SUPABASE_URL` and `SUPABASE_SERVICE_ROLE_KEY` as server environment variables in Render.
6. Deploy, then share the URL Render provides.

## Files

- `server.js` — API and static website server
- `public/` — browser interface
- `sql/schema.sql` — database tables
- `.env.example` — environment variable template (no secrets)
- `.gitignore` — keeps `.env` and `node_modules` out of Git

## Important

This is a learning/demo project. Anyone with access to the public site can add shared knowledge. Facts may be inaccurate. There is only basic input validation, no accounts, no moderation, and no rate limiting. Do not submit private information. The server's Supabase service key must stay secret and server-side.

This web starter recreates the shared relationship and Q&A features; it does not automatically compile or run the original `kakashi.c` terminal program.
